import torch
import os
import seaborn as sns
from torch.utils.data import DataLoader,TensorDataset


class DEEPmodel(torch.nn.Module):

    def __init__(self,input_size = 1000,feature_size = 256, nb_class = 5, nb_couche=1):
        super(DEEPmodel, self).__init__()
        input_size = input_size
        output_size = feature_size
        liste = []
        self.norm = torch.nn.BatchNorm1d(input_size)
        for i in range(nb_couche):
            liste.append(torch.nn.Linear(input_size, output_size))
            liste.append(torch.nn.BatchNorm1d(output_size))
            liste.append(torch.nn.ReLU())
            input_size = output_size
        self.layers =  torch.nn.ModuleList(liste)
        self.out_linear = torch.nn.Linear(output_size, nb_class)
    def forward(self, x):
        x = self.norm(x)
        for layer in self.layers:
            x = layer(x)
        x = self.out_linear(x)
        return x
    
class DEEPmodel_2(torch.nn.Module):

    def __init__(self,input_size = 1000,features = [256,256,16], sub_features =[16,16], nb_class = 5):
        super(DEEPmodel_2, self).__init__()
        input_size = input_size-6
        
        liste = []
        self.norm = torch.nn.BatchNorm1d(input_size)
        for f in features:
            liste.append(torch.nn.Linear(input_size, f))
            liste.append(torch.nn.BatchNorm1d(f))
            liste.append(torch.nn.ReLU())
            liste.append(torch.nn.Dropout(0.1))
            input_size = f
        self.layers =  torch.nn.ModuleList(liste)
        self.subnorm = torch.nn.BatchNorm1d(6)
        liste = []
        input_size = 6
        for sf in sub_features:
            liste.append(torch.nn.Linear(input_size, sf))
            liste.append(torch.nn.BatchNorm1d(sf))
            liste.append(torch.nn.ReLU())
            liste.append(torch.nn.Dropout(0.1))
            input_size = sf
        self.sublayers =  torch.nn.ModuleList(liste)
        self.out_linear = torch.nn.Linear(sf + f, nb_class)

    def forward(self, x):
        sub_x = x[:,:6]
        sub_x = self.subnorm(sub_x)
        for layer in self.sublayers:
            sub_x = layer(sub_x)
        
        x = x[:,6:]
        x = self.norm(x)
        for layer in self.layers:
            x = layer(x)
        x = torch.cat((sub_x,x),dim = 1)
        x = self.out_linear(x)
        return x