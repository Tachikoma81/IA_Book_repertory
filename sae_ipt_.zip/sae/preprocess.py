import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import torch
import os
import seaborn as sns
from torch.utils.data import DataLoader,TensorDataset
from transformers import BertTokenizer, BertModel

def get_meta_info(data_valid,titre_info, author_data,genre_data,editor_data):

    #A partir du titre de chaque rating, on va extraire le genre, l'auteur et l'editeur et on rajoutes ces informations dans le dataframe ratings
    ratings_books = data_valid[['Titre','rating']].values
    ratings_books[:,1]=ratings_books[:,1].astype(float)    
    ratings_author = []
    nb_rat_auhtor = []
    ratings_genre = []
    nb_rat_genre = []
    ratings_editor = []
    nb_rat_editor = []

    for i in range(len(ratings_books)):
        titre = ratings_books[i][0]
        if titre in titre_info:
            if titre_info[titre]['Auteurs'] in author_data:
                ratings_author.append(author_data[titre_info[titre]['Auteurs']][0])
                nb_rat_auhtor.append(author_data[titre_info[titre]['Auteurs']][1])
            else:
                ratings_author.append(2.5)
                nb_rat_auhtor.append(0)
            if titre_info[titre]['Genre'] in genre_data:
                ratings_genre.append(genre_data[titre_info[titre]['Genre']][0])
                nb_rat_genre.append(genre_data[titre_info[titre]['Genre']][1])
            else:
                ratings_genre.append(2.5)
                nb_rat_genre.append(0)
            if titre_info[titre]['Editeur'] in editor_data:
                ratings_editor.append(editor_data[titre_info[titre]['Editeur']][0])
                nb_rat_editor.append(editor_data[titre_info[titre]['Editeur']][1])
            else:
                ratings_editor.append(2.5)
                nb_rat_editor.append(0)
        else:
            ratings_author.append(0)
            nb_rat_auhtor.append(2.5)
            ratings_genre.append(0)
            nb_rat_genre.append(2.5)
            ratings_editor.append(0)
            nb_rat_editor.append(2.5)
    return ratings_author, nb_rat_auhtor, ratings_genre, nb_rat_genre, ratings_editor, nb_rat_editor



def get_freq_emmbeddings(data,model=None,size_vocabulary = 1000): 
    X = None
    if model :
        X = model.transform(data)
    else:
        model = CountVectorizer(stop_words = "english", max_features = size_vocabulary,ngram_range=(1, 2))
        X = model.fit_transform(data)
    return X.toarray(),model

def get_tf_idfs_emmbeddings(data,model=None,size_vocabulary = 1000):
    
    X = None
    if model :
        X = model.transform(data)
    else:
        model = TfidfVectorizer(stop_words = "english", max_features = size_vocabulary,ngram_range=(1, 2))
        X = model.fit_transform(data)
    return X.toarray(),model

def get_bert_embeddings_batch(data,model,tokenizer):
    inputs = tokenizer(data, return_tensors='pt', truncation=True, max_length=512, padding=True)
    with torch.no_grad():
        outputs = model(**inputs)
    
    cls_embedding = outputs.last_hidden_state[:, 0, :]
    
    return cls_embedding

def get_bert_embeddings(data, batch_size = 128):
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertModel.from_pretrained('bert-base-uncased')
    nb_batch = len(data)//batch_size
    res = None
    for i in range(nb_batch+1):
        print("*",end="")
        data_batch = data[i*batch_size:(i+1)*batch_size]
        if len(data_batch)!=0:
            embeddings = get_bert_embeddings_batch(data_batch,model,tokenizer)
            if res is None:
                res = embeddings
            else:
                res = torch.cat((res,embeddings),0)
        else:
            print("ZERO")
    print()
    return res